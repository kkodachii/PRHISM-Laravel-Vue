<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Low Stock  Report</title>
    <style>
        @page { margin: 140px 50px; }

         body {
             font-family: "Helvetica";
             font-weight: 400;
             font-style: normal;
         }

         .header {
             position: fixed;
             left: 0px;
             top: -120px;
             right: 0px;
             width: 100%;
             align-items: center;
             justify-content: space-between;
             border-bottom: 3px solid #000;
         }

         .header img {
             border-radius: 50%;
             max-width: 10rem;
             padding: 0.25rem;
             aspect-ratio: 1;
         }

         .header h3 {
             font-size: 1.25rem;
             font-weight: bold;
             margin-bottom: 0.25rem;
         }

         .header p {
             padding: 0rem;
             font-size: 0.8rem;
         }

         h1 {
             font-family: "Helvetica";
             font-size: 2rem;
             font-weight: bold;
             margin-bottom: 1rem;
             margin-top: 0rem;
         }

         h2 {
             font-family: "Helvetica";
             font-size: 1.25rem;
             font-weight: 600;
             margin-bottom: 0.5rem;
         }

         table {
             width: 100%;
             background-color: #fff;
             border: 1px solid #000;
             border-collapse: collapse;
         }

         th{
             border: 1px solid #000;
             background-color: rgb(187, 187, 187);
         }

         td{
             border: 1px solid #000;
             text-align: center;
         }

         .borderless{
             border: none;
         }

         .space-between {
            border-collapse: separate;
            border-spacing: 0 1em;
        }
     </style>
 </head>
 <body>
     <div class="header" width="100%">
         <table class="borderless">
             <tr>
                 <td class="borderless" style="width: 30%; text-align:left;">
                     <img src="<?php echo e(public_path('prhism/logo.svg')); ?>" alt="Logo" style="width: 100px;">
                 </td>
                 <td class="borderless" style="width: 70%; text-align: right;">
                     <h3>RHU Paombong</h3>
                     <table class="borderless">
                             <tr>
                                 <td class="borderless" style="text-align: right;">Email: mho.paombong@gmail.com</td>
                             </tr>
                             <tr>
                                 <td class="borderless" style="text-align: right;">Phone: +63 446651202</td>
                             </tr>
                             <tr>
                                 <td class="borderless" style="text-align: right;">Location: Brgy. Poblacion, Paombong, Bulacan</td>
                             </tr>
                     </table>
                 </td>
             </tr>
         </table>
     </div>

    <h1 style="font-size: 25px; margin-bottom: 25px; text-align: center;">Low Stock Report <span style="font-weight: 400"><?php echo e($date); ?></span></h1>
    <p>
        <span><span style="font-weight:300">Threshold: </span><?php echo e($threshold); ?></span>
    </p>
<?php if($medicines->isNotEmpty()): ?>
    <h2>Medicines</h2>
    <table>
        <thead>
            <tr>
                <th>Quantity</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Category</th>
                <th>Batch</th>
                <th>Expiration Date</th>
                <th>Date Acquired</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($medicine->quantity); ?></td>
                <td><?php echo e($medicine->generic_name->generic_name); ?></td>
                <td><?php echo e($medicine->brand); ?></td>
                <td><?php echo e($medicine->category->category); ?></td>
                <td><?php echo e($medicine->batch->batch_number); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($medicine->expiration_date)->format('F j, Y')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($medicine->rawDateAcquired)->format('F j, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>

<?php if($equipments->isNotEmpty()): ?>
    <h2>Equipment</h2>
    <table>
        <thead>
            <tr>
                <th>Quantity</th>
                <th>Name</th>
                <th>Description</th>
                <th>Batch</th>
                <th>Date Acquired</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($equip->quantity); ?></td>
                <td><?php echo e($equip->equipment_name); ?></td>
                <td><?php echo e($equip->description); ?></td>
                <td><?php echo e($equip->batch->batch_number); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($equip->rawDateAcquired)->format('F j, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>

<?php if($medicalSupplies->isNotEmpty()): ?>
    <h2>Medical Supplies</h2>
    <table>
        <thead>
            <tr>
                <th>Quantity</th>
                <th>Name</th>
                <th>Description</th>
                <th>Batch</th>
                <th>Date Acquired</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $medicalSupplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($supply->quantity); ?></td>
                <td><?php echo e($supply->med_sup_name); ?></td>
                <td><?php echo e($supply->description); ?></td>
                <td><?php echo e($supply->batch->batch_number); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($supply->rawDateAcquired)->format('F j, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>

</body>
</html>
<?php /**PATH C:\Users\Administrator\Documents\Laravel Projects\web_prhism_paombong\resources\views\reports\low-stock-report.blade.php ENDPATH**/ ?>