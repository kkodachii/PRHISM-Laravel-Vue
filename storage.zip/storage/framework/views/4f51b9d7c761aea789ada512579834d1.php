<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Most Requested Report</title>
    <style>
        @page { margin: 140px 50px; }

         body {
             font-family: "Helvetica";
             font-weight: 400;
             font-style: normal;
         }

         .header {
             position: fixed;
             left: 0px;
             top: -120px;
             right: 0px;
             width: 100%;
             align-items: center;
             justify-content: space-between;
             border-bottom: 3px solid #000;
         }

         .header img {
             border-radius: 50%;
             max-width: 10rem;
             padding: 0.25rem;
             aspect-ratio: 1;
         }

         .header h3 {
             font-size: 1.25rem;
             font-weight: bold;
             margin-bottom: 0.25rem;
         }

         .header p {
             padding: 0rem;
             font-size: 0.8rem;
         }

         h1 {
             font-family: "Helvetica";
             font-size: 2rem;
             font-weight: bold;
             margin-bottom: 1rem;
             margin-top: 0rem;
         }

         h2 {
             font-family: "Helvetica";
             font-size: 1.25rem;
             font-weight: 600;
             margin-bottom: 0.5rem;
         }

         table {
             width: 100%;
             background-color: #fff;
             border: 1px solid #000;
             border-collapse: collapse;
         }

         th{
             border: 1px solid #000;
             background-color: rgb(187, 187, 187);
         }

         td{
             border: 1px solid #000;
             text-align: center;
         }

         .borderless{
             border: none;
         }

         .space-between {
            border-collapse: separate;
            border-spacing: 0 1em;
        }
     </style>
 </head>
 <body>
     <div class="header" width="100%">
         <table class="borderless">
             <tr>
                 <td class="borderless" style="width: 30%; text-align:left;">
                     <img src="<?php echo e(public_path('prhism/logo.svg')); ?>" alt="Logo" style="width: 100px;">
                 </td>
                 <td class="borderless" style="width: 70%; text-align: right;">
                     <h3>RHU Paombong</h3>
                     <table class="borderless">
                             <tr>
                                 <td class="borderless" style="text-align: right;">Email: mho.paombong@gmail.com</td>
                             </tr>
                             <tr>
                                 <td class="borderless" style="text-align: right;">Phone: +63 446651202</td>
                             </tr>
                             <tr>
                                 <td class="borderless" style="text-align: right;">Location: Brgy. Poblacion, Paombong, Bulacan</td>
                             </tr>
                     </table>
                 </td>
             </tr>
         </table>
     </div>

    <h1 style="font-size: 25px; margin-bottom: 25px; text-align: center;">Most Requested Report <span style="font-weight: 400"><?php echo e($date); ?></span></h1>
    <p>
        <span><span style="font-weight:300">Type: </span><?php echo e($type); ?></span>
        <span><span style="font-weight:300">Limit: </span><?php echo e($limit); ?></span>
    </p>
<?php if($mostRequestedItems->isNotEmpty()): ?>
    <table>
        <thead>
            <tr>
                <th>Frequency</th>
                <th>Quantity</th>
                <th>Name</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mostRequestedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->total_requests); ?></td>
                <td><?php echo e(ucfirst($item->type)); ?></td>
                <td><?php echo e($item->name); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>

</body>
</html>
<?php /**PATH C:\Users\Administrator\Documents\Laravel Projects\web_prhism_paombong\resources\views\reports\most-requested-report.blade.php ENDPATH**/ ?>