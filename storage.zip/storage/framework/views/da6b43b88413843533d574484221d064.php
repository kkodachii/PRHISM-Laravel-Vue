<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Requests Report</title>
    <style>
        @page { margin: 140px 50px; }

         body {
             font-family: "Helvetica";
             font-weight: 400;
             font-style: normal;
         }

         .header {
             position: fixed;
             left: 0px;
             top: -120px;
             right: 0px;
             width: 100%;
             align-items: center;
             justify-content: space-between;
             border-bottom: 3px solid #000;
         }

         .header img {
             border-radius: 50%;
             max-width: 10rem;
             padding: 0.25rem;
             aspect-ratio: 1;
         }

         .header h3 {
             font-size: 1.25rem;
             font-weight: bold;
             margin-bottom: 0.25rem;
         }

         .header p {
             padding: 0rem;
             font-size: 0.8rem;
         }

         h1 {
             font-family: "Helvetica";
             font-size: 2rem;
             font-weight: bold;
             margin-bottom: 1rem;
             margin-top: 0rem;
         }

         h2 {
             font-family: "Helvetica";
             font-size: 1.25rem;
             font-weight: 600;
             margin-bottom: 0.5rem;
         }

         table {
             width: 100%;
             background-color: #fff;
             border: 1px solid #000;
             border-collapse: collapse;
         }

         th{
             border: 1px solid #000;
             background-color: rgb(187, 187, 187);
         }

         td{
             border: 1px solid #000;
             text-align: center;
         }

         .borderless{
             border: none;
         }

         .space-between {
            border-collapse: separate;
            border-spacing: 0 1em;
        }
     </style>
 </head>
 <body>
     <div class="header" width="100%">
         <table class="borderless">
             <tr>
                 <td class="borderless" style="width: 30%; text-align:left;">
                     <img src="<?php echo e(public_path('prhism/logo.svg')); ?>" alt="Logo" style="width: 100px;">
                 </td>
                 <td class="borderless" style="width: 70%; text-align: right;">
                     <h3>RHU Paombong</h3>
                     <table class="borderless">
                             <tr>
                                 <td class="borderless" style="text-align: right;">Email: mho.paombong@gmail.com</td>
                             </tr>
                             <tr>
                                 <td class="borderless" style="text-align: right;">Phone: +63 446651202</td>
                             </tr>
                             <tr>
                                 <td class="borderless" style="text-align: right;">Location: Brgy. Poblacion, Paombong, Bulacan</td>
                             </tr>
                     </table>
                 </td>
             </tr>
         </table>
     </div>

    <h1 style="font-size: 25px; margin-bottom: 25px; text-align: center;">Requests Report: <span style="font-weight: 400"><?php echo e($date); ?></span></h1>
    <p><span style="font-weight:300">Condition: </span><?php echo e($status ?? 'Delivered'); ?></p>

     <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <span style="font-weight:300">Request #<?php echo e($index + 1); ?></span>
     <table style="margin-bottom: 0.25em;">
         <thead>
             <tr>
                 <th>Status</th>
                 <th>Barangay</th>
                 <th>Requester Name</th>
                 <th>Date Requested</th>
                 <th>Date Approved</th>
                 <th>RHU</th>
                 <th>Approver Name</th>
                 <th>Approver Position</th>
             </tr>
         </thead>
         <tbody>
             <tr>
                 <td><?php echo e($request->status); ?></td>
                 <td><?php echo e($request->barangay->barangay_name); ?></td>
                 <td><?php echo e($request->requester_user->name); ?></td>
                 <td><?php echo e(\Carbon\Carbon::parse($request->updated_at)->format('F j, Y')); ?></td>
                 <td><?php echo e(\Carbon\Carbon::parse($request->date_approved)->format('F j, Y')); ?></td>
                 <td><?php echo e($request->approver_rhu); ?></td>
                 <td><?php echo e($request->approver_name); ?></td>
                 <td><?php echo e($request->approver_position); ?></td>
             </tr>
         </tbody>
     </table>
     <table style="margin-top: 0.25em;">
        <thead>
            <tr>
                <th>Medicines</th>
                <th>Equipments</th>
                <th>Medical Supplies</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php $__currentLoopData = $request->requestedItems['medicines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($medicine['generic_name']); ?> (<?php echo e($medicine['quantity']); ?> x)<br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $request->requestedItems['equipment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($equipment['equipment_name']); ?> (<?php echo e($equipment['quantity']); ?> x)<br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $request->requestedItems['supplies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($supply['medical_supply_name']); ?> (<?php echo e($supply['quantity']); ?> x)<br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        </tbody>
    </table>

     <div style="height: 1em;">&nbsp;</div> 
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>
<?php /**PATH C:\Users\Administrator\Documents\Laravel Projects\web_prhism_paombong\resources\views\reports\request-report.blade.php ENDPATH**/ ?>