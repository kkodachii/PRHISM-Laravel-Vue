<!DOCTYPE html>
<html>
<head>
    <title>Laravel Mail</title>
</head>
<body>
    <p>Thank you</p>
</body>
</html>
<?php /**PATH C:\Users\Administrator\Documents\Laravel Projects\web_prhism_paombong\resources\views\test-mail.blade.php ENDPATH**/ ?>